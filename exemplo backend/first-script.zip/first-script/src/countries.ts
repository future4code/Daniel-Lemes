export const country: {
   nome: string,
   capital: string,
   continente: string
} = {
   nome: "Brasil",
   capital: "Brasília",
   continente: "América do sul"
}