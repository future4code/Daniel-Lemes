const num1: number = Number(process.argv[2])
const num2: number = Number(process.argv[3])

let message = "hello"


console.log(num1 + num2)     // imprime uma mensagem no terminal

message = "hello"
// message = false
// message = undefined

console.log(message)